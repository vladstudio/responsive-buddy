chrome.commands.onCommand.addListener((command) => {
    console.log(`Command "${command}" triggered`);
});